import java.util.Scanner;

public class decisionFactory {
	// use getPlan method to get object of type Plan
	public Decision getDecision(String decisionType) {
		if (decisionType == null) {
			return null;
		}
		if (decisionType.equalsIgnoreCase("POST")) {
			return new PostAction();
		} else if (decisionType.equalsIgnoreCase("GET")) {
			return new GetAction();
		} else if (decisionType.equalsIgnoreCase("DELETE")) {
			System.out.println("DeleteAction instance");

			System.out.println("enter ID\n");// Example id :
												// acdc4303d722310020c153b2b2520369
			@SuppressWarnings("resource")
			Scanner scn = new Scanner(System.in);
			String ID = scn.nextLine();
			return new DeleteAction(ID);
		}
		return null;
	}
}
