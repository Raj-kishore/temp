
import java.io.*;

import org.apache.http.HttpException;      
abstract class Decision{  
         abstract void decideCall() throws IOException, HttpException;   
}//end of Decision class.  