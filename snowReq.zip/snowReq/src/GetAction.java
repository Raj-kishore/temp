
import java.io.IOException;
import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
//	Ref :
//	https://docs.servicenow.com/bundle/geneva-servicenow-platform/page/integrate/inbound_rest/reference/r_TableAPIJavaExamples.html
public class GetAction  extends Decision {

	public void getRequest() throws HttpException, IOException {
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(
				new AuthScope(new HttpHost("")), // "httpbin.org",
																												// 80
				new UsernamePasswordCredentials("")); // "user",
																					  // "passwd"
		CloseableHttpClient httpclient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();

		try {  
			HttpGet httpget = new HttpGet("https://"); // http://httpbin.org/basic-auth/user/passwd
			httpget.setHeader("Accept", "application/json");
			System.out.println("Executing request " + httpget.getRequestLine());
			CloseableHttpResponse response = httpclient.execute(httpget);	
			try {
				System.out.println("----------------------------------------");
				System.out.println(response.getStatusLine());
				String responseBody = EntityUtils.toString(response.getEntity());
				System.out.println(responseBody);
			} finally {
				response.close();
			}
		} finally {
			httpclient.close();
		}
	}
	// default output
	/**
	 * Executing request GET http://httpbin.org/basic-auth/user/passwd HTTP/1.1
	 * ---------------------------------------- HTTP/1.1 200 OK {
	 * "authenticated": true, "user": "user" }
	 * 
	 * 
	 **/

	@Override
	void decideCall() throws IOException, HttpException {
		System.out.println("GetAction instance");
		GetAction restAction = new GetAction();
		restAction.getRequest();
	}

}