import java.io.IOException;
import java.util.Scanner;

import org.apache.http.HttpException;

public class generateDecision {
	public static void main(String[] args) {
		System.out.print("Enter API decision: POST/GET/DELETE \n");
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		String getFactoryVal = in.nextLine();

		decisionFactory dFactory = new decisionFactory();

		Decision p = dFactory.getDecision(getFactoryVal);
		try {
			p.decideCall();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (HttpException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			System.out.println("No such requests found. Reload.");
		}
	}

}
