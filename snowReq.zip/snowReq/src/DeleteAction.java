
import java.io.IOException;
import java.util.Scanner;

import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class DeleteAction extends Decision {
	private static String IDx;

	public DeleteAction(String ID) {
		IDx = ID;
	}

	@Override
	void decideCall() throws IOException, HttpException {
		System.out.println("DeleteAction instance :: ID : " + IDx);
		DeleteAction restAction = new DeleteAction(IDx);
		restAction.deleteRequest();
	}

	public void deleteRequest() throws HttpException, IOException {
		// This must be valid json string with valid fields and values from
		// table

		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(new AuthScope(new HttpHost(".com")), // "httpbin.org",
				// 80
				new UsernamePasswordCredentials("")); // "user",
		// "passwd"
		CloseableHttpClient httpclient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();

		try {
			HttpDelete httpDelete = new HttpDelete("https:///" + IDx);
			httpDelete.setHeader("Accept", "application/json");

			System.out.println("Executing request " + httpDelete.getRequestLine());
			CloseableHttpResponse response = httpclient.execute(httpDelete);
			try {
				System.out.println("----------------------------------------");
				System.out.println(response.getStatusLine());
			} finally {
				response.close();
			}
		} finally {
			httpclient.close();
		}
	}
}