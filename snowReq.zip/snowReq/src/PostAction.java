import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import java.util.Scanner;

public class PostAction extends Decision {
	public String getConsoleInput;

	public void postRequest() throws HttpException, IOException {
		// This must be valid json string with valid fields and values from
		// table
		System.out.println("Enter json ex. {\"short_description\":\"Test with java post\"}\n");
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		getConsoleInput = in.nextLine();
		System.out.println("Input string " + getConsoleInput);
		System.out.println("Inserting...");

		// String postData = "{\"short_description\":\"Test with java post\"}";
		String postData = getConsoleInput;
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(new AuthScope(new HttpHost("sncapappsonedev.service-now.com")),
				new UsernamePasswordCredentials("Eyeshare.ITIL2", "Automation.COE1"));
		CloseableHttpClient httpclient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();

		try {
			HttpPost httpPost = new HttpPost("https://sncapappsonedev.service-now.com/api/now/table/incident");
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-Type", "application/json");
			HttpEntity entity = new ByteArrayEntity(postData.getBytes("utf-8"));
			httpPost.setEntity(entity);

			System.out.println("Executing request " + httpPost.getRequestLine());
			CloseableHttpResponse response = httpclient.execute(httpPost);
			try {
				System.out.println("----------------------------------------");
				System.out.println(response.getStatusLine());
				String responseBody = EntityUtils.toString(response.getEntity());
				System.out.println(responseBody);
			} finally {
				response.close();
			}
		} finally {
			httpclient.close();
		}
	}

	@Override
	void decideCall() throws IOException, HttpException {
		System.out.println("PostAction instance");
		PostAction restAction = new PostAction();
		restAction.postRequest();
	}

}