import elasticsearch
from elasticsearch.helpers import scan
import json
import os

def downloadIndicies(preProdServer,domain):
  #es = elasticsearch.Elasticsearch('https://http://inmummaiatstsrv.corp.capgemini.com:9200')
  es = elasticsearch.Elasticsearch([{u'host': preProdServer , u'port': b'9200'}])
  for index in es.indices.get('*'+domain+'*'):
    print (index)
  patternObjlist = es.indices.get('*'+domain+'*')
  for src in patternObjlist:
      count = 0
      os.chdir("C:\\Users\\ramahara\\Desktop\\elastic dumper\\sources")
      if not os.path.exists(src):
          os.mkdir(src)
      else:
          pass
          #print(src + " folder already exists")
      os.chdir("C:\\Users\\ramahara\\Desktop\\elastic dumper\\sources\\" + src)
      print("Now in " + os.getcwd())
      es_response = scan(
              es,
              index= src,
              doc_type='_doc',
              request_timeout=100,
              query={"query": {"match_all": {}}}
      )
      for item in es_response:
                  count+=1
                  file_name = item['_source']['title']
                  print(file_name)
                  f = open(str(count)+".txt", "w")
                  stringfy = json.dumps(item['_source'], indent=4, sort_keys=True)
                  f.write(stringfy)
                  #print(json.dumps(item)
                  print(item['_source'])


if __name__ == "__main__":
    preProdServer = u'inmummaiatstsrv.corp.capgemini.com'
    devServer = u'inmummaiadevsrv.corp.capgemini.com'
    prodServer = u'frparmaia-es-0.corp.capgemini.com'
    domain = 'erp'
    downloadIndicies(preProdServer,domain)