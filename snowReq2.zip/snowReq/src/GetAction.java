
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.*;


//	Ref :
//	https://docs.servicenow.com/bundle/geneva-servicenow-platform/page/integrate/inbound_rest/reference/r_TableAPIJavaExamples.html
public class GetAction extends Decision {

	public static String tempID = "";
	public static String jsonData = "";
	public static String partJson = "";
	

	public void getRequest() throws HttpException, IOException {
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(new AuthScope(new HttpHost("sncapappsonedev.service-now.com")), // "httpbin.org",
																										// 80
				new UsernamePasswordCredentials("Eyeshare.ITIL2", "Automation.COE1")); // "user",
																						// "passwd"
		CloseableHttpClient httpclient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();

		try {
			HttpGet httpget = new HttpGet("https://sncapappsonedev.service-now.com/api/now/table/incident"); // http://httpbin.org/basic-auth/user/passwd
			httpget.setHeader("Accept", "application/json");
			System.out.println("Executing request " + httpget.getRequestLine());
			CloseableHttpResponse response = httpclient.execute(httpget);
			try {
				System.out.println("----------------------------------------");
				System.out.println(response.getStatusLine());
				String responseBody = EntityUtils.toString(response.getEntity());
				System.out.println(responseBody);
				jsonData = responseBody;
			} finally {
				response.close();
			}
		} finally {
			httpclient.close();
		}
	}

	// default output
	/**
	 * Executing request GET http://httpbin.org/basic-auth/user/passwd HTTP/1.1
	 * ---------------------------------------- HTTP/1.1 200 OK {
	 * "authenticated": true, "user": "user" }
	 * @throws ParseException 
	 * 
	 * 
	 **/

	@Override
	void decideCall() throws IOException, HttpException, ParseException {
		System.out.println("GetAction instance");
		GetAction restAction = new GetAction();
		restAction.getRequest();

		List<String> list = new ArrayList<String>();
		//Object obj = new JSONParser().parse(new FileReader("C:\\Users\\ramahara\\Desktop\\resource\\new 10.txt"));
		Object obj = new JSONParser().parse(jsonData);
		JSONObject jo = (JSONObject) obj;
		JSONArray ja = (JSONArray) jo.get("result");
		System.out.println("Subtotal indices " + ja.size() + "\n\n");
		Iterator itr2 = ja.iterator();
		int i = 0;
		while (itr2.hasNext()) {
			i++;
			System.out.print("Obj " + i + " :: ");
			Iterator<Map.Entry> itr1 = ((Map) itr2.next()).entrySet().iterator();
			while (itr1.hasNext()) {
				Map.Entry pair = itr1.next();
				partJson = (String) itr2.next();
				if (pair.getKey().equals("sys_id")) {
					tempID = pair.getValue().toString();
				}
				if (pair.getKey().equals("short_description")) {
					String gv = (String) pair.getValue();
					if (gv.toLowerCase().contains("hda")) {
						System.out.println("hda found with sysid,,, " + tempID);
						// calling the delete function
						//new DeleteAction(tempID);
						//save in text file 
						try {
						    Files.write(Paths.get("C:\\Users\\ramahara\\Desktop\\resource\\myFile.txt"), partJson.getBytes(), StandardOpenOption.APPEND);
						}catch (IOException e) {
						    //exception handling left as an exercise for the reader
							System.out.println(e);
						}
						tempID = "";
					} else {
						System.out.println("***");
						tempID = "";
					}
				}
			
			partJson = "";
			}
			System.out.println("-----------------------------------------------------------");
		}
	}
}