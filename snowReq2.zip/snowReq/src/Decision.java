
import java.io.*;

import org.apache.http.HttpException;
import org.json.simple.parser.ParseException;      
abstract class Decision{  
         abstract void decideCall() throws IOException, HttpException, ParseException;   
}//end of Decision class.  